package com.apkharsh.inventory.controllers;

import com.apkharsh.inventory.models.Book;
import com.apkharsh.inventory.models.User;
import com.apkharsh.inventory.service.BookService;
import com.apkharsh.inventory.service.UserService;
import com.apkharsh.inventory.utils.CustomResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class BookController {

    @Autowired
    public BookService bookService;

    @Autowired
    public UserService userService;


    @GetMapping("/books/all/{userID}")
    public ResponseEntity<?> getAllBooks(@PathVariable("userID") String userID){

        if(!userService.isAuthorized(userID)) {
            return new ResponseEntity<>(new CustomResponse("You are not authorized to perform this action"), HttpStatus.UNAUTHORIZED);
        }

        List<Book> books = bookService.getAllBooks();

        if(books == null){
            return new ResponseEntity<>(new CustomResponse("No books found"), HttpStatus.NOT_FOUND);
        }
        else {
            return new ResponseEntity<>(books, HttpStatus.FOUND);
        }
    }

    @GetMapping("/books/name/{bookName}/{userID}")
    public ResponseEntity<?> getBookByName(@PathVariable("bookName") String name, @PathVariable("userID") String userID){

        if(!userService.isAuthorized(userID)) {
            return new ResponseEntity<>(new CustomResponse("You are not authorized to perform this action"), HttpStatus.UNAUTHORIZED);
        }

        Book book = bookService.getBookByName(name);

        if(book != null){
            return new ResponseEntity<>(book, HttpStatus.FOUND);
        }
        else{
            return new ResponseEntity<>(new CustomResponse("No book found with this name"), HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/books/id/{bookID}/{userID}")
    public ResponseEntity<?> getBookByID(@PathVariable("bookID") String bookID, @PathVariable("userID") String userID){

        if(!userService.isAuthorized(userID)) {
            return new ResponseEntity<>(new CustomResponse("You are not authorized to perform this action"), HttpStatus.UNAUTHORIZED);
        }

        Book book = bookService.getBookById(bookID);

        if(book != null){
            return new ResponseEntity<>(book, HttpStatus.FOUND);
        }
        else{
            return new ResponseEntity<>(new CustomResponse("No book found with this ID"), HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/books/add/{userID}")
    public ResponseEntity<?> addBook(@RequestBody Book book, @PathVariable("userID") String userID){

        if(!userService.isAuthorized(userID)) {
            return new ResponseEntity<>(new CustomResponse("You are not authorized to perform this action"), HttpStatus.UNAUTHORIZED);
        }

        if(bookService.addBook(book)){
            return new ResponseEntity<>(book, HttpStatus.CREATED);
        }
        else{
            return new ResponseEntity<>(new CustomResponse("This book already exists"), HttpStatus.CONFLICT);
        }
    }

    @DeleteMapping("/books/delete/{bookID}/{userID}")
    public ResponseEntity<?> deleteBook(@PathVariable("bookID") String bookID, @PathVariable("userID") String userID){

        if(!userService.isAuthorized(userID)) {
            return new ResponseEntity<>(new CustomResponse("You are not authorized to perform this action"), HttpStatus.UNAUTHORIZED);
        }

        if(bookService.deleteBook(bookID)){
            return new ResponseEntity<>(new CustomResponse("book with Id " + bookID + " is deleted successfully"), HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(new CustomResponse("No book found with this ID"), HttpStatus.NOT_FOUND);
        }
    }

    @PatchMapping("/books/update/{userID}")
    public ResponseEntity<?> updateBookDetails(@PathVariable("userID") String userID, @RequestBody Book book){

        if(!userService.isAuthorized(userID)) {
            System.out.println("autorised");
            return new ResponseEntity<>(new CustomResponse("You are not authorized to perform this action"), HttpStatus.UNAUTHORIZED);
        }

        if(bookService.updateBookDetails(book)){
            System.out.println("updated");
            return new ResponseEntity<>(book, HttpStatus.OK);
        }
        else{
            System.out.println("not updated");
            return new ResponseEntity<>(new CustomResponse("Book already exists with same name"), HttpStatus.CONFLICT);
        }
    }

    @PatchMapping("/books/{bookID}/update/quantity/{userID}")
    public ResponseEntity<?> updateBookQuantity(@PathVariable("userID") String userID, @PathVariable String bookID, @RequestBody int quantity){

        if(!userService.isAuthorized(userID)) {
            return new ResponseEntity<>(new CustomResponse("You are not authorized to perform this action"), HttpStatus.UNAUTHORIZED);
        }

        if(bookService.updateBookQuantity(bookID, quantity)){
            return new ResponseEntity<>(new CustomResponse("quantity updated successfully"), HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(new CustomResponse("Book does not exist with this ID"), HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/books/author/{authorName}/{userID}")
    public ResponseEntity<?> getBooksByAuthor(@PathVariable("authorName") String authorName, @PathVariable("userID") String userID){

        if(!userService.isAuthorized(userID)) {
            return new ResponseEntity<>(new CustomResponse("You are not authorized to perform this action"), HttpStatus.UNAUTHORIZED);
        }

        List<Book> books = bookService.getBooksByAuthor(authorName);

        if(books == null){
            return new ResponseEntity<>(new CustomResponse("No books found"), HttpStatus.NOT_FOUND);
        }
        else {
            return new ResponseEntity<>(books, HttpStatus.FOUND);
        }
    }
}
