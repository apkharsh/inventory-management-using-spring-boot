package com.apkharsh.inventory.service;

import com.apkharsh.inventory.models.Book;
import com.apkharsh.inventory.repositories.BookRepo;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class BookServiceTest {
    @Mock
    private BookRepo bookRepo;

    @InjectMocks
    private BookService bookService;

    @Test
    public void addBook_book_added_Test() {

        Book book_1 = new Book("1", "atomic habits", "self help", "temp", 2023);

        when(bookRepo.findByBookName(anyString())).thenReturn(null);
        boolean actualResult = bookService.addBook(book_1);
        assertTrue(actualResult);
    }

    @Test
    public void addBook_book_not_added_Test() {

        Book book_1 = new Book("1", "atomic habits", "self help", "temp", 2023);

        when(bookRepo.findByBookName(anyString())).thenReturn(book_1);

        // Stub the behavior of bookRepo.save()
        //doNothing().when(bookRepo).save(any());

        boolean actualResult = bookService.addBook(book_1);

        assertFalse(actualResult);
    }

    @Test
    public void getAllBooksTest() {

        // Expected list
        Book book_1 = new Book("1", "atomic habits", "self help", "temp", 2023);
        Book book_2 = new Book("1", "atomic habits", "self help", "temp", 2023);

        List<Book> expectedBooksList = new ArrayList<>();
        expectedBooksList.add(book_1);
        expectedBooksList.add(book_2);

        // actual list
        List<Book> databaseList = new ArrayList<>();
        databaseList.add(book_1);
        databaseList.add(book_2);

        when(bookRepo.findAll()).thenReturn(databaseList);

        List<Book> actualList = bookService.getAllBooks();
        assertEquals(expectedBooksList, actualList);
    }

    // empty lists
    @Test
    public void getAllBooksTest_EmptyList() {

        List<Book> expectedBooksList = new ArrayList<>();
        List<Book> databaseList = new ArrayList<>();

        when(bookRepo.findAll()).thenReturn(databaseList);

        List<Book> actualList = bookService.getAllBooks();
        assertEquals(expectedBooksList, actualList);
    }

    @Test
    public void getBookByIDTest() {

        Book book_1 = new Book("1", "atomic habits", "self help", "temp", 2023);
        when(bookRepo.findById("1")).thenReturn(Optional.of(book_1));

        Book actualResult = bookService.getBookById("1");

        assertEquals(book_1, actualResult);
    }

    @Test
    public void getBookByNameTest() {

        Book book_1 = new Book("1", "atomic habits", "self help", "temp", 2023);
        when(bookRepo.findByBookName("atomic habits")).thenReturn(book_1);

        Book actualResult = bookService.getBookByName("atomic habits");
        assertEquals(book_1, actualResult);
    }

    @Test
    public void getBooksByAuthorNameTest() {

        Book book_1 = new Book("1", "atomic habits", "self help", "harsh", 2023);

        List<Book> expectedList = new ArrayList<>();
        expectedList.add(book_1);

        List<Book> actualList = new ArrayList<>();
        actualList.add(book_1);

        when(bookRepo.findByAuthorName("harsh")).thenReturn(actualList);

        List<Book> actualResult = bookService.getBooksByAuthor("harsh");
        assertEquals(expectedList, actualResult);

    }

    @Test
    public void deleteBook_bookExists_Test() {

        Book book_1 = new Book("1", "atomic habits", "self help", "harsh", 2023);
        when(bookRepo.findById(anyString())).thenReturn(Optional.of(book_1));

        boolean actualResult = bookService.deleteBook(book_1.getID());
        assertTrue(actualResult);

        verify(bookRepo, times(1)).findById(anyString());
    }

    @Test
    public void deleteBook_bookNotExists_test() {
        
        String nonExistingBookID = "456";
        when(bookRepo.findById(nonExistingBookID)).thenReturn(Optional.empty());

        boolean result = bookService.deleteBook(nonExistingBookID);

        assertFalse(result);
        verify(bookRepo, never()).deleteById(nonExistingBookID);
    }

    @Test
    public void deleteBook_bookExists_test() {

        Book book_1 = new Book("1", "atomic habits", "self help", "temp", 2023);

        // Stub the getBookById method to return the sample book when called with the given bookID
        when(bookRepo.findById("1")).thenReturn(Optional.of(book_1));

        // Call the deleteBook method
        boolean result = bookService.deleteBook("1");

        // Verify that the getBookById method was called once with the provided bookID
        verify(bookRepo, times(1)).findById("1");

        // Verify that the deleteById method was called once with the provided bookID
        verify(bookRepo, times(1)).deleteById("1");

        // Assert that the result is true, as the book exists and should be deleted
        assertTrue(result);
    }

}
